.. _advanced-options:

Advanced Options
================

The following advanced global configuration options can be used for all esptool commands. They are placed before the command name on the command line. For example, the option ``--before no-reset`` has to be placed before ``flash-id``. The command should look like this: ``esptool --before no-reset flash-id``.

For basic/fundamental global configuration options, see the :ref:`options` page.

Reset Modes
-----------

By default, esptool tries to hard reset the chip into bootloader mode before it starts and hard resets the chip to run the normal program once it is complete. The ``--before`` and ``--after`` options allow this behavior to be changed:

Reset Before Operation: ``--before``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The ``--before`` argument allows you to specify whether the chip needs resetting into bootloader mode before esptool talks to it.

.. list::

    * ``--before default-reset`` is the default, which uses DTR & RTS serial control lines (see :ref:`entering-the-bootloader`) to try to reset the chip into bootloader mode.
    * ``--before no-reset`` will skip DTR/RTS control signal assignments and just start sending a serial synchronisation command to the chip. This is useful if your chip doesn't have DTR/RTS, or for some serial interfaces (like Arduino board onboard serial) which behave differently when DTR/RTS are toggled.
    * ``--before no-reset-no-sync`` will skip DTR/RTS control signal assignments and skip also the serial synchronization command. This is useful if your chip is already running the :ref:`stub bootloader <stub>` and you want to avoid resetting the chip and uploading the stub again.
    :USB_SERIAL_JTAG_SUPPORTED: * ``--before usb-reset`` will use custom reset sequence for USB-JTAG-Serial (used for example for ESP chips connected through the USB-JTAG-Serial peripheral). Usually, this option doesn't have to be used directly. Esptool should be able to detect connection through USB-JTAG-Serial.

.. _after-reset:

Reset After Operation: ``--after``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The ``--after`` argument allows you to specify whether the chip should be reset after the esptool operation completes:

.. list::

    * ``--after hard-reset`` is the default. It resets the chip into the normal boot sequence. With a USB-to-UART adapter, the RTS serial control line is normally connected to the chip's enable pin.
    :esp8266: * ``--after soft-reset`` runs the user firmware, but any subsequent reset will return to the serial bootloader. This was the reset behaviour in esptool v1.x.
    * ``--after no-reset`` leaves the chip in the serial bootloader, no reset is performed.
    * ``--after no-reset-stub`` leaves the chip in the stub bootloader, no reset is performed.
    :WATCHDOG_RESET_SUPPORTED: * ``--after watchdog-reset`` hard-resets the chip by triggering an internal watchdog. See :ref:`Watchdog Reset Limitations <wdt-reset-limitations>`.

If a :ref:`custom hard reset sequence <custom-reset-sequences>` is defined in the configuration file, it replaces the sequence used by ``--after hard-reset``. Esptool reports the executed sequence, so the output always shows which one was used.

.. only:: USB_SERIAL_JTAG_SUPPORTED

    With USB-Serial/JTAG, the peripheral interprets the RTS serial control
    signal as a core reset. This reset does not re-sample the boot strapping
    pins, so a chip that entered download mode manually may remain there.

    .. only:: WATCHDOG_RESET_SUPPORTED

        If this happens, ``--after watchdog-reset`` can be used to trigger a
        full system reset.

.. only:: USB_OTG_SUPPORTED and WATCHDOG_RESET_SUPPORTED

    When USB-OTG is detected, ``--after hard-reset`` may automatically use an
    internal watchdog reset where required and supported. A custom hard reset
    sequence is not used in that case, because no serial control lines are
    involved.

Connect Loop
------------

Esptool supports connection loops, where the user can specify how many times to try to open a port. The delay between retries is 0.1 seconds. This can be useful for example when the chip is in deep sleep or esptool was started before the chip was connected to the PC. A connection loop can be created by setting the ``ESPTOOL_OPEN_PORT_ATTEMPTS`` environment variable.
This feature can also be enabled by using the ``open_port_attempts`` configuration option, for more details regarding config options see :ref:`Configuration file <config>` section.
There are 3 possible values for this option:

.. list::

    * ``0`` will keep trying to connect to the chip indefinitely
    * ``1`` will try to connect to the chip only once (default)
    * ``N`` will try to connect to the chip N times


.. note::

    This option is only available if both the ``--port`` and ``--chip`` arguments are set.



.. _disable_stub:

Disabling the Stub Loader: ``--no-stub``
----------------------------------------

The ``--no-stub`` option disables uploading of a software "stub loader" that manages flash operations, and only talks directly to the loader in ROM.

Passing ``--no-stub`` will disable certain options, as not all options are implemented in every chip's ROM loader.

.. only:: CUSTOM_SPI_FLASH_PINS_SUPPORTED

    Overriding SPI Flash Connections: ``--spi-connection``
    ------------------------------------------------------

    The optional ``--spi-connection`` argument overrides the SPI flash connection configuration on {IDF_TARGET_NAME}. This means that the SPI flash can be connected to other pins, or esptool can be used to communicate with a different SPI flash chip to the default.

    Supply the ``--spi-connection`` argument after the ``esptool`` command. A custom pin mapping uses the form ``esptool flash-id --spi-connection <CLK>,<Q>,<D>,<HD>,<CS>``.

    .. note::

        Only NOR flash chips that are capable of at least Dual I/O (DIO) mode for SPI communication are supported. SPI NAND flash chips, as well as other types of memory devices that do not meet this requirement, are not supported.

    Default Behavior
    ^^^^^^^^^^^^^^^^

    If the ``--spi-connection`` argument is not provided, the SPI flash uses the same pins that are used during a normal boot.

    These pins can be configured using :ref:`SPI pad eFuses <espefuse-spi-flash-pins>`.

    .. only:: esp32

        SPI Mode
        ^^^^^^^^

        ``--spi-connection SPI`` uses the default SPI pins:

        * CLK = GPIO 6
        * Q = GPIO 7
        * D = GPIO 8
        * HD = GPIO 9
        * CS = GPIO 11

        During normal booting, this configuration is selected if all SPI pin eFuses are unset and GPIO1 (U0TXD) is not pulled low (default).

        This is the normal pin configuration for ESP32 chips that do not contain embedded flash.

        HSPI Mode
        ^^^^^^^^^

        ``--spi-connection HSPI`` uses the HSPI peripheral instead of the SPI peripheral for SPI flash communications, via the following HSPI pins:

        * CLK = GPIO 14
        * Q = GPIO 12
        * D = GPIO 13
        * HD = GPIO 4
        * CS = GPIO 15

        During normal booting, this configuration is selected if all SPI pin eFuses are unset and GPIO1 (U0TXD) is pulled low on reset.

    Custom SPI Pin Configuration
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    ``--spi-connection <CLK>,<Q>,<D>,<HD>,<CS>`` allows a custom list of pins to be configured for the SPI flash connection. This can be used to emulate the flash configuration equivalent to a particular set of SPI pin eFuses being burned. The values supplied are GPIO numbers.

    .. only:: esp32

        For example, ``--spi-connection 6,17,8,11,16`` sets an identical configuration to the factory eFuse configuration for ESP32s with embedded flash.

    .. note::

        Some GPIO pins might be shared with other peripherals. Therefore, some SPI pad pin configurations might not work reliably or at all. Use a different combination of pins if you encounter issues.

Specifying Arguments via File
-----------------------------
.. _specify_arguments_via_file:

Anywhere on the esptool command line, you can specify a file name as ``@filename.txt`` to read one or more arguments from text file ``filename.txt``. Arguments can be separated by newlines or spaces, quotes can be used to enclose arguments that span multiple words. Arguments read from the text file are expanded exactly as if they had appeared in that order on the esptool command line.

An example of this is available in the :ref:`merge-bin <merge-bin>` command description.

.. note::

    PowerShell users need to add quotes around @filename.txt ("@filename.txt") for it to be correctly resolved. This is because of `splatting <https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_splatting?view=powershell-7.3>`__, a method of passing a collection of parameter values to a command as a unit.

Filtering Serial Ports: ``--port-filter``
-----------------------------------------
.. _filtering_serial_ports:

``--port-filter <FilterType>=<FilterValue>`` allows limiting ports that will be considered during chip autodetection. This can be useful when esptool is run on a system
with many serial ports. There are a few different types that can be combined. A port must match all specified FilterTypes, and must match
at least one FilterValue for each specified FilterType to be considered. Example filter configurations:

.. list::

    * ``--port-filter vid=0x303A`` matches ports with the Espressif USB VID.
    * ``--port-filter vid=0x303A --port-filter vid=0x0403`` matches Espressif and FTDI ports by VID.
    * ``--port-filter vid=0x303A --port-filter pid=0x0002`` matches Espressif ESP32-S2 in USB-OTG mode by VID and PID.
    * ``--port-filter vid=0x303A --port-filter pid=0x1001`` matches Espressif USB-Serial/JTAG unit used by multiple chips by VID and PID.
    * ``--port-filter name=ttyUSB`` matches ports where the port name contains the specified text.
    * ``--port-filter serial=7c98d1065267ee11bcc4c8ab93cd958c`` matches ports where the serial number contains the specified text.

See also the `Espressif USB customer-allocated PID repository <https://github.com/espressif/usb-pids>`_

Output and CLI Appearance
-------------------------

Output verbosity can be controlled using the ``--verbose`` and ``--silent`` flags.

Verbose Output: ``--verbose``, ``-v``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. _verbose:

The ``--verbose``, ``-v`` flag can be used to show all output without any overwriting or collapsing stages into a single line:

.. code-block:: bash

    esptool --verbose flash-id

See :ref:`the trace option <tracing-communications>` if you want to dump all serial interactions to the standard output for debugging purposes.

Silent Output: ``--silent``, ``-s``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. _silent:

The ``--silent``, ``-s`` flag can be used to limit the output to errors only:

.. code-block:: bash

    esptool -s write-flash 0x0 image.bin

.. _disabling_color_output:

Disabling Color Output
^^^^^^^^^^^^^^^^^^^^^^

Esptool may emit ANSI color codes in terminal output (for example, errors in red).
If this causes problems when redirecting output or parsing logs, set the ``NO_COLOR``
environment variable before running esptool:

.. code-block:: bash

    NO_COLOR=1 esptool flash-id

Any non-empty value disables color output. This follows the `NO_COLOR <https://no-color.org/>`__
convention and applies to ``esptool``, ``espefuse``, ``espsecure`` and ``esp_rfc2217_server``.

CLI Help Themes
^^^^^^^^^^^^^^^

If the default ``--help`` styling is hard to read in your terminal (for example on
a light or non-standard background), you can choose a different theme with the
``RICH_CLICK_THEME`` environment variable:

.. code-block:: bash

    RICH_CLICK_THEME=solarized-slim esptool -h

To keep the setting for the rest of the shell session, export it instead:

.. code-block:: bash

    export RICH_CLICK_THEME=solarized-slim

See the `rich-click themes documentation
<https://ewels.github.io/rich-click/latest/documentation/themes/>`__ for available
themes and further options. ``RICH_CLICK_THEME`` customizes ``--help`` styling only;
to disable colors in all terminal output (including help), use ``NO_COLOR`` instead.
